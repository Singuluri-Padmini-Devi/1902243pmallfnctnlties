document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('upload-form');
    const searchForm = document.getElementById('search-form');
    const resultDiv = document.getElementById('result');
    const searchResultsDiv = document.getElementById('search-results');

    uploadForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(uploadForm);

        resultDiv.innerHTML = '<p>Processing your file, please wait...</p>';

        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                resultDiv.innerHTML = `<p class="error">${data.error}</p>`;
            } else {
                const format = document.getElementById('format-select').value;
                resultDiv.innerHTML = `<pre>${format === 'json' ? data.json : format === 'csv' ? data.csv : data.text}</pre>`;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            resultDiv.innerHTML = '<p class="error">An error occurred while processing your file.</p>';
        });
    });

    searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const query = document.getElementById('search-query').value.trim();

        searchResultsDiv.innerHTML = '<p>Searching, please wait...</p>';

        fetch('/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                searchResultsDiv.innerHTML = `<p class="error">${data.error}</p>`;
            } else {
                const resultsHtml = data.results.map(result => `<p>${result}</p>`).join('');
                searchResultsDiv.innerHTML = resultsHtml || '<p>No matching results found.</p>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            searchResultsDiv.innerHTML = '<p class="error">An error occurred during the search.</p>';
        });
    });
});
